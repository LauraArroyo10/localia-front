// TODO: Define User and Auth related types

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  role: "user" | "business_owner" | "admin";
  createdAt: Date;
}

export interface AuthCredentials {
  email: string;
  password: string;
}

export interface RegisterData extends AuthCredentials {
  name: string;
}
