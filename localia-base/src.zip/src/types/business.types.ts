// TODO: Define Business and Place related types

export type Category =
  | "artisan_goods"
  | "local_food"
  | "culture"
  | "beach"
  | "mountain"
  | "town_places";

export type ServiceType = "service" | "activity" | "product";

export interface Place {
  id: string;
  name: string;
  description: string;
  location: string;
  coordinates?: { lat: number; lng: number };
  imageUrl?: string;
  category: Category;
}

export interface Business extends Place {
  ownerId: string;
  email: string;
  phone?: string;
  address: string;
  serviceType: ServiceType;
  services: string[];
  rating: number;
  reviewCount: number;
  images: string[];
  isVerified: boolean;
}
