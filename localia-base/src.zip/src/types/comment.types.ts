// TODO: Define Comment and Post related types

export interface Comment {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatarUrl?: string;
  businessId: string;
  content: string;
  rating: number;
  createdAt: Date;
}

export interface Post {
  id: string;
  authorId: string;
  businessId: string;
  title: string;
  content: string;
  imageUrl?: string;
  createdAt: Date;
}
