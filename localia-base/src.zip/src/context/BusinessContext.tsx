import { createContext, useContext, useState, type ReactNode } from "react";
import { Business } from "../models";
import { businessService } from "../services";
import type { Business as IBusiness } from "../types";

interface BusinessContextValue {
  currentBusiness: Business | null;
  isLoading: boolean;
  error: string | null;
  fetchBusiness: (id: string) => Promise<void>;
  updateBusiness: (id: string, data: Partial<IBusiness>) => Promise<void>;
  clearBusiness: () => void;
}

const BusinessContext = createContext<BusinessContextValue | null>(null);

export function BusinessProvider({ children }: { children: ReactNode }) {
  const [currentBusiness, setCurrentBusiness] = useState<Business | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchBusiness = async (id: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await businessService.getById(id);
      setCurrentBusiness(new Business(data));
    } catch {
      setError("No se pudo cargar el negocio.");
    } finally {
      setIsLoading(false);
    }
  };

  const updateBusiness = async (id: string, data: Partial<IBusiness>) => {
    // TODO: Optimistic update + revalidate
    const updated = await businessService.update(id, data);
    setCurrentBusiness(new Business(updated));
  };

  const clearBusiness = () => setCurrentBusiness(null);

  return (
    <BusinessContext.Provider
      value={{
        currentBusiness,
        isLoading,
        error,
        fetchBusiness,
        updateBusiness,
        clearBusiness,
      }}
    >
      {children}
    </BusinessContext.Provider>
  );
}

export function useBusiness() {
  const ctx = useContext(BusinessContext);
  if (!ctx) throw new Error("useBusiness must be used inside <BusinessProvider>");
  return ctx;
}
