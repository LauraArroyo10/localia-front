import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { User } from "../models";
import { authService } from "../services";
import type { AuthCredentials, RegisterData, User as IUser } from "../types";

interface AuthContextValue {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (credentials: AuthCredentials) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // TODO: Check token in localStorage and restore session
    setIsLoading(false);
  }, []);

  const login = async (credentials: AuthCredentials) => {
    // TODO: Save token to localStorage
    const { user: userData } = await authService.login(credentials);
    setUser(new User(userData as IUser));
  };

  const register = async (data: RegisterData) => {
    const { user: userData } = await authService.register(data);
    setUser(new User(userData as IUser));
  };

  const logout = async () => {
    // TODO: Clear token from localStorage
    await authService.logout();
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{ user, isLoading, isAuthenticated: !!user, login, register, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}
