import { createContext, useContext, useState, type ReactNode } from "react";
import type { Business, Category } from "../types";
import { businessService } from "../services";
import { Business as BusinessModel } from "../models";

interface SearchContextValue {
  query: string;
  setQuery: (q: string) => void;
  selectedCategory: Category | null;
  setSelectedCategory: (c: Category | null) => void;
  results: BusinessModel[];
  isSearching: boolean;
  search: (q?: string) => Promise<void>;
}

const SearchContext = createContext<SearchContextValue | null>(null);

export function SearchProvider({ children }: { children: ReactNode }) {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [results, setResults] = useState<BusinessModel[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const search = async (q?: string) => {
    setIsSearching(true);
    try {
      // TODO: Add category filter to query params
      const data = await businessService.getAll(q ?? query);
      setResults(data.map((b: Business) => new BusinessModel(b)));
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <SearchContext.Provider
      value={{
        query,
        setQuery,
        selectedCategory,
        setSelectedCategory,
        results,
        isSearching,
        search,
      }}
    >
      {children}
    </SearchContext.Provider>
  );
}

export function useSearch() {
  const ctx = useContext(SearchContext);
  if (!ctx) throw new Error("useSearch must be used inside <SearchProvider>");
  return ctx;
}
