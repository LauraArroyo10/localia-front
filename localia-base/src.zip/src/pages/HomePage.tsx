import type { FC } from "react";

// TODO: Implement HomePage  (route: /)
// Compose layout + sections + cards from components/

const HomePage: FC = () => {
  return (
    <main>
      {/* TODO: HomePage layout */}
    </main>
  );
};

export default HomePage;
