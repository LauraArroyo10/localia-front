import type { FC } from "react";

// TODO: Implement AuthPage  (route: /login  /signup)
// Compose layout + sections + cards from components/

const AuthPage: FC = () => {
  return (
    <main>
      {/* TODO: AuthPage layout */}
    </main>
  );
};

export default AuthPage;
