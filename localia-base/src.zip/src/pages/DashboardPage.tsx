import type { FC } from "react";

// TODO: Implement DashboardPage  (route: /dashboard)
// Compose layout + sections + cards from components/

const DashboardPage: FC = () => {
  return (
    <main>
      {/* TODO: DashboardPage layout */}
    </main>
  );
};

export default DashboardPage;
