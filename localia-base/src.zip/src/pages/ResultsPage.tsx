import type { FC } from "react";

// TODO: Implement ResultsPage  (route: /search)
// Compose layout + sections + cards from components/

const ResultsPage: FC = () => {
  return (
    <main>
      {/* TODO: ResultsPage layout */}
    </main>
  );
};

export default ResultsPage;
