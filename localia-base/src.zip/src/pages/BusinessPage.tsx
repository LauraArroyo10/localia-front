import type { FC } from "react";

// TODO: Implement BusinessPage  (route: /business/:id)
// Compose layout + sections + cards from components/

const BusinessPage: FC = () => {
  return (
    <main>
      {/* TODO: BusinessPage layout */}
    </main>
  );
};

export default BusinessPage;
