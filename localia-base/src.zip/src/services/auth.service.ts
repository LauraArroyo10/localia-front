import { apiService } from "./api.service";
import type { User, AuthCredentials, RegisterData } from "../types";

// TODO: Implement real auth endpoints
export const authService = {
  login: (credentials: AuthCredentials) =>
    apiService.post<{ user: User; token: string }>("/auth/login", credentials),

  register: (data: RegisterData) =>
    apiService.post<{ user: User; token: string }>("/auth/register", data),

  logout: () => apiService.post<void>("/auth/logout", {}),

  getMe: () => apiService.get<User>("/auth/me"),
};
