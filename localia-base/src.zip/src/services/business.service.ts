import { apiService } from "./api.service";
import type { Business } from "../types";

// TODO: Implement business endpoints
export const businessService = {
  getAll: (query?: string) =>
    apiService.get<Business[]>(`/businesses${query ? `?q=${query}` : ""}`),

  getById: (id: string) => apiService.get<Business>(`/businesses/${id}`),

  create: (data: Partial<Business>) =>
    apiService.post<Business>("/businesses", data),

  update: (id: string, data: Partial<Business>) =>
    apiService.put<Business>(`/businesses/${id}`, data),
};
