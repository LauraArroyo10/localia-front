// TODO: Add more formatting helpers as needed

export function formatDate(date: Date | string): string {
  return new Date(date).toLocaleDateString("es-CR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function truncate(text: string, max = 120): string {
  return text.length > max ? text.slice(0, max) + "\u2026" : text;
}

export function slugify(text: string): string {
  return text.toLowerCase().replace(/\s+/g, "-").replace(/[^\w-]/g, "");
}
