import type { FC } from "react";

// TODO: Implement Slider component
// Design reference: Figma LOCALIA — UI átomos

interface SliderProps {
  // TODO: Define props
  className?: string;
}

const Slider: FC<SliderProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: Slider */}
    </div>
  );
};

export default Slider;
