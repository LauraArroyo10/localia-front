import type { FC } from "react";

// TODO: Implement SearchBar component
// Design reference: Figma LOCALIA — UI átomos

interface SearchBarProps {
  // TODO: Define props
  className?: string;
}

const SearchBar: FC<SearchBarProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: SearchBar */}
    </div>
  );
};

export default SearchBar;
