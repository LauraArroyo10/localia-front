import type { FC } from "react";

// TODO: Implement ImagePopup component
// Design reference: Figma LOCALIA — UI átomos

interface ImagePopupProps {
  // TODO: Define props
  className?: string;
}

const ImagePopup: FC<ImagePopupProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: ImagePopup */}
    </div>
  );
};

export default ImagePopup;
