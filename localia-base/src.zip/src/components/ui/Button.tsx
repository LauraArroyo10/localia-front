import type { FC } from "react";

// TODO: Implement Button component
// Design reference: Figma LOCALIA — UI átomos

interface ButtonProps {
  // TODO: Define props
  className?: string;
}

const Button: FC<ButtonProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: Button */}
    </div>
  );
};

export default Button;
