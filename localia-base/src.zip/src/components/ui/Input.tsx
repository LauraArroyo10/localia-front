import type { FC } from "react";

// TODO: Implement Input component
// Design reference: Figma LOCALIA — UI átomos

interface InputProps {
  // TODO: Define props
  className?: string;
}

const Input: FC<InputProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: Input */}
    </div>
  );
};

export default Input;
