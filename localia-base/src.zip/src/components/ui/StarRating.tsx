import type { FC } from "react";

// TODO: Implement StarRating component
// Design reference: Figma LOCALIA — UI átomos

interface StarRatingProps {
  // TODO: Define props
  className?: string;
}

const StarRating: FC<StarRatingProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: StarRating */}
    </div>
  );
};

export default StarRating;
