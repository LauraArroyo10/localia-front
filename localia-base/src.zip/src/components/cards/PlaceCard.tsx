import type { FC } from "react";

// TODO: Implement PlaceCard component
// Design reference: Figma LOCALIA — Cards

interface PlaceCardProps {
  // TODO: Define props
  className?: string;
}

const PlaceCard: FC<PlaceCardProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: PlaceCard */}
    </div>
  );
};

export default PlaceCard;
