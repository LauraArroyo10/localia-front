import type { FC } from "react";

// TODO: Implement PostCard component
// Design reference: Figma LOCALIA — Cards

interface PostCardProps {
  // TODO: Define props
  className?: string;
}

const PostCard: FC<PostCardProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: PostCard */}
    </div>
  );
};

export default PostCard;
