import type { FC } from "react";

// TODO: Implement ProfileCard component
// Design reference: Figma LOCALIA — Cards

interface ProfileCardProps {
  // TODO: Define props
  className?: string;
}

const ProfileCard: FC<ProfileCardProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: ProfileCard */}
    </div>
  );
};

export default ProfileCard;
