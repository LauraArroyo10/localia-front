import type { FC } from "react";

// TODO: Implement CommentCard component
// Design reference: Figma LOCALIA — Cards

interface CommentCardProps {
  // TODO: Define props
  className?: string;
}

const CommentCard: FC<CommentCardProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: CommentCard */}
    </div>
  );
};

export default CommentCard;
