import type { FC } from "react";

// TODO: Implement ImageButton component
// Design reference: Figma LOCALIA — Cards

interface ImageButtonProps {
  // TODO: Define props
  className?: string;
}

const ImageButton: FC<ImageButtonProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: ImageButton */}
    </div>
  );
};

export default ImageButton;
