import type { FC } from "react";

// TODO: Implement Header component
// Design reference: Figma LOCALIA — Layout

interface HeaderProps {
  className?: string;
}

const Header: FC<HeaderProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: Header */}
    </div>
  );
};

export default Header;
