import type { FC } from "react";

// TODO: Implement Navbar component
// Design reference: Figma LOCALIA — Layout

interface NavbarProps {
  className?: string;
}

const Navbar: FC<NavbarProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: Navbar */}
    </div>
  );
};

export default Navbar;
