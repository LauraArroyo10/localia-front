import type { FC } from "react";

// TODO: Implement Footer component
// Design reference: Figma LOCALIA — Layout

interface FooterProps {
  className?: string;
}

const Footer: FC<FooterProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: Footer */}
    </div>
  );
};

export default Footer;
