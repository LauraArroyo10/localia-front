import type { FC } from "react";

// TODO: Implement MapView component
// Design reference: Figma LOCALIA — Secciones

interface MapViewProps {
  // TODO: Define props
  className?: string;
}

const MapView: FC<MapViewProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: MapView */}
    </div>
  );
};

export default MapView;
