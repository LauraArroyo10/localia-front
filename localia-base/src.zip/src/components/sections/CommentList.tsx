import type { FC } from "react";

// TODO: Implement CommentList component
// Design reference: Figma LOCALIA — Secciones

interface CommentListProps {
  // TODO: Define props
  className?: string;
}

const CommentList: FC<CommentListProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: CommentList */}
    </div>
  );
};

export default CommentList;
