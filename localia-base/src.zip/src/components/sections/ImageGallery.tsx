import type { FC } from "react";

// TODO: Implement ImageGallery component
// Design reference: Figma LOCALIA — Secciones

interface ImageGalleryProps {
  // TODO: Define props
  className?: string;
}

const ImageGallery: FC<ImageGalleryProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: ImageGallery */}
    </div>
  );
};

export default ImageGallery;
