import type { FC } from "react";

// TODO: Implement Carousel component
// Design reference: Figma LOCALIA — Secciones

interface CarouselProps {
  // TODO: Define props
  className?: string;
}

const Carousel: FC<CarouselProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: Carousel */}
    </div>
  );
};

export default Carousel;
