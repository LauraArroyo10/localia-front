import type { FC } from "react";

// TODO: Implement CardGrid component
// Design reference: Figma LOCALIA — Secciones

interface CardGridProps {
  // TODO: Define props
  className?: string;
}

const CardGrid: FC<CardGridProps> = ({ className }) => {
  return (
    <div className={className}>
      {/* TODO: CardGrid */}
    </div>
  );
};

export default CardGrid;
