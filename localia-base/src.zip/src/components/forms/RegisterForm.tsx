import type { FC } from "react";

// TODO: Implement RegisterForm component
// Design reference: Figma LOCALIA — Formularios

interface RegisterFormProps {
  onSuccess?: () => void;
  className?: string;
}

const RegisterForm: FC<RegisterFormProps> = ({ onSuccess, className }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Handle form submission
    onSuccess?.();
  };

  return (
    <form onSubmit={handleSubmit} className={className}>
      {/* TODO: RegisterForm fields */}
    </form>
  );
};

export default RegisterForm;
