import type { FC } from "react";

// TODO: Implement BusinessForm component
// Design reference: Figma LOCALIA — Formularios

interface BusinessFormProps {
  onSuccess?: () => void;
  className?: string;
}

const BusinessForm: FC<BusinessFormProps> = ({ onSuccess, className }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Handle form submission
    onSuccess?.();
  };

  return (
    <form onSubmit={handleSubmit} className={className}>
      {/* TODO: BusinessForm fields */}
    </form>
  );
};

export default BusinessForm;
