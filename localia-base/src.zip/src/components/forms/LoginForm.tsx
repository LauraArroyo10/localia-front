import type { FC } from "react";

// TODO: Implement LoginForm component
// Design reference: Figma LOCALIA — Formularios

interface LoginFormProps {
  onSuccess?: () => void;
  className?: string;
}

const LoginForm: FC<LoginFormProps> = ({ onSuccess, className }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Handle form submission
    onSuccess?.();
  };

  return (
    <form onSubmit={handleSubmit} className={className}>
      {/* TODO: LoginForm fields */}
    </form>
  );
};

export default LoginForm;
