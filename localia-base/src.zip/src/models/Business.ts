import type { Business as IBusiness } from "../types";
import { Place } from "./Place";

// TODO: Implement Business class — extends Place
export class Business extends Place implements IBusiness {
  ownerId: string;
  email: string;
  phone?: string;
  address: string;
  serviceType: IBusiness["serviceType"];
  services: string[];
  rating: number;
  reviewCount: number;
  images: string[];
  isVerified: boolean;

  constructor(data: IBusiness) {
    super(data);
    this.ownerId = data.ownerId;
    this.email = data.email;
    this.phone = data.phone;
    this.address = data.address;
    this.serviceType = data.serviceType;
    this.services = data.services;
    this.rating = data.rating;
    this.reviewCount = data.reviewCount;
    this.images = data.images;
    this.isVerified = data.isVerified;
  }

  getAverageRating(): string {
    // TODO: Format rating display
    return this.rating.toFixed(1);
  }

  getMainImage(): string {
    // TODO: Return first image or placeholder
    return this.images[0] ?? "";
  }
}
