import type { User as IUser } from "../types";

// TODO: Implement User class
export class User implements IUser {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  role: IUser["role"];
  createdAt: Date;

  constructor(data: IUser) {
    this.id = data.id;
    this.name = data.name;
    this.email = data.email;
    this.avatarUrl = data.avatarUrl;
    this.role = data.role;
    this.createdAt = data.createdAt;
  }

  isBusinessOwner(): boolean {
    return this.role === "business_owner";
  }

  getInitials(): string {
    // TODO: Return first letter of each word in name
    return this.name
      .split(" ")
      .map((w) => w[0])
      .join("")
      .toUpperCase();
  }
}
