import type { Place as IPlace, Category } from "../types";

// TODO: Implement Place class methods
export class Place implements IPlace {
  id: string;
  name: string;
  description: string;
  location: string;
  coordinates?: { lat: number; lng: number };
  imageUrl?: string;
  category: Category;

  constructor(data: IPlace) {
    this.id = data.id;
    this.name = data.name;
    this.description = data.description;
    this.location = data.location;
    this.coordinates = data.coordinates;
    this.imageUrl = data.imageUrl;
    this.category = data.category;
  }

  getShortDescription(maxChars = 100): string {
    // TODO: Return trimmed description
    return this.description.slice(0, maxChars);
  }

  hasCoordinates(): boolean {
    return !!this.coordinates;
  }
}
